/*
     File:       NSLUtility.h
 
     Contains:   Interface to API for using the NSL Manager
 
     Version:    Technology: Mac OS 8.5
                 Release:    QuickTime 6.0.2
 
     Copyright:  (c) 1985-2001 by Apple Computer, Inc., all rights reserved
 
     Bugs?:      For bug reports, consult the following page on
                 the World Wide Web:
 
                     http://developer.apple.com/bugreporter/
 
*/
#ifndef __NSLUTILITY__
#define __NSLUTILITY__


// This file is obsolete.  Please delete it from your sources.


#endif /* __NSLUTILITY__ */


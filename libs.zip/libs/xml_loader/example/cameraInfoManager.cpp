
#include "cameraInfoManager.h"


cameraInfoManager::cameraInfoManager() {
	// load data:
	
	
	/*ParamIO outXml;
	outXml.write("PARAMS:TEXT", "sd");
	outXml.write("PARAMS:COLOR:RED",   3);
	outXml.write("PARAMS:COLOR:GREEN", 2);
	outXml.write("PARAMS:COLOR:BLUE",  5);
	outXml.write("PARAMS:FONT:NAME", "sdf");
	outXml.write("PARAMS:FONT:SIZE", "asdfsad");
	outXml.writeFile("filename.xml"); // Finally write the file to disk
	*/	
	
	
	loadCamInfo();
	bogusCamInfo();
	convertCamInputIntoCams();
	calculateClippingEquations();
}



void cameraInfoManager::bogusCamInfo(){
	for (int i = 0; i < NUM_CAM_POSITIONS; i++){
		
		cams[i].pos.x = i * 40.0f;
		cams[i].pos.y = 20.0f;
		cams[i].pos.z = 0.0f;
		
		cams[i].up.x = 0.0f;
		cams[i].up.y = 5.0f;
		cams[i].up.z = 0.0f;
		
		cams[i].at.x = cams[i].pos.x + 10.0f;
		cams[i].at.y = cams[i].pos.y + 20.0f;
		cams[i].at.z = cams[i].pos.z + 5.0f;
		
		cams[i].fieldOfView = 60.0f;
		
		cams[i].r = 0.0f;
		cams[i].g = 0.0f;
		cams[i].b = 0.0f;
	}
	

		
}

/* Test a sphere's bounding box against the six clip planes */
int cameraInfoManager::culled (int camNum, sgBbox sb)
{
    int i, j;
    int culled;

    for (i=0; i<6; i++) {
        culled = 0;
        for (j=0; j<8; j++) {
            if (distanceFromPlane(camClipEqs[camNum].planeEqs[i], sb.bbox[j]) < 0){
                culled |= 1<<j;
                //printf("j = %i dist = %f \n", j,distanceFromPlane(camClipEqs[camNum].planeEqs[i], sb.bbox[j]));
                }
        }
        if (culled==0xff)
            /* All eight vertices of bounding box are trivially culled */
            return 0;
    }
   
    /* Not trivially culled. Probably visible. */
    return 1;
}



void cameraInfoManager::convertCamInputIntoCams(){

	for (int i = 0; i < NUM_CAM_POSITIONS; i++){
			
		acVec3f temp1 = camInputs[i].pts[1] - camInputs[i].pts[0];
		acVec3f temp2 = camInputs[i].pts[2] - camInputs[i].pts[1];
		
		acVec3f mid = camInputs[i].pts[0] + camInputs[i].pts[1] + 
						  camInputs[i].pts[2] + camInputs[i].pts[3];
		mid /= 4.0f;
		
		acVec3f midForUp = camInputs[i].pts[2] + camInputs[i].pts[3];
		midForUp /= 2.0f;
		
		acVec3f cross1 = camInputs[i].pts[1] - camInputs[i].pts[0];
		acVec3f cross2 = camInputs[i].pts[3] - camInputs[i].pts[0];
		
		// switch direction for floor projection
		if (i >= 8 && i <12){
			cross2 = camInputs[i].pts[0] - camInputs[i].pts[3];
		
		}
		
	 	acVec3f cross = cross2.cross(cross1);
		cross.normalize();	  	 
		
		float mazoEyeX = temp1.length() / 2.0;
		float mazoEyeY = temp2.length() / 2.0;
		float halfFov = PI * camInputs[i].fov / 360.0;
		float theTan = tanf(halfFov);
		float mazoDist = mazoEyeY / theTan;
		float mazoNearDist = mazoDist / 10.0;
		float mazoFarDist = mazoDist * 10.0;
		float mazoAspect = (float)temp1.length()/temp2.length();
		
		
		cross *= mazoDist;
		acVec3f final = mid + cross;
		
		cams[i].fieldOfView = camInputs[i].fov;
		cams[i].r = 0.0f;
		cams[i].g = 0.0f;
		cams[i].b = 0.0f;
		
				
		cams[i].pos.set(final);
		cams[i].at.set(mid); 
		cams[i].up.set(mid - midForUp);
	}
}

void cameraInfoManager::loadCamInfo(){


	ParamIO inXml;
	inXml.readFile("cameras.xml");
	char temp[100];
	for (int i = 0; i < NUM_CAM_POSITIONS; i++){
		for (int j = 0; j < 4; j++){
			sprintf(temp, "PARAMS:camera_%i:pt%i:x", i, j);
			inXml.read(temp,camInputs[i].pts[j].x,0.0f);
			sprintf(temp, "PARAMS:camera_%i:pt%i:y", i, j);
			inXml.read(temp,camInputs[i].pts[j].y,0.0f);
			sprintf(temp, "PARAMS:camera_%i:pt%i:z", i, j);
			inXml.read(temp,camInputs[i].pts[j].z,0.0f);
			sprintf(temp, "PARAMS:camera_%i:fov", i, j);
			camInputs[i].pts[j].x *= 10.0f;
			camInputs[i].pts[j].y *= 10.0f;
			camInputs[i].pts[j].z *= 10.0f;
			inXml.read(temp,camInputs[i].fov,60.0f);
			//camInputs[i].fov = 40.0f;
			
 		}
 	}
 		
 		
}

void cameraInfoManager::fillPacket( berlinPacket * BP){
	// that's it
	memcpy(BP->cams, cams, NUM_CAM_POSITIONS * sizeof(cameraInfo));
}

//-----------------------------------------------------
static void matrixConcatenate (float *result, float *ma, float *mb)
{
    int i;
    double mb00, mb01, mb02, mb03,
           mb10, mb11, mb12, mb13,
           mb20, mb21, mb22, mb23,
           mb30, mb31, mb32, mb33;
    double mai0, mai1, mai2, mai3;

    mb00 = mb[0];  mb01 = mb[1];
    mb02 = mb[2];  mb03 = mb[3];
    mb10 = mb[4];  mb11 = mb[5];
    mb12 = mb[6];  mb13 = mb[7];
    mb20 = mb[8];  mb21 = mb[9];
    mb22 = mb[10];  mb23 = mb[11];
    mb30 = mb[12];  mb31 = mb[13];
    mb32 = mb[14];  mb33 = mb[15];

    for (i = 0; i < 4; i++) {
        mai0 = ma[i*4+0];  mai1 = ma[i*4+1];
	     mai2 = ma[i*4+2];  mai3 = ma[i*4+3];

        result[i*4+0] = mai0 * mb00 + mai1 * mb10 + mai2 * mb20 + mai3 * mb30;
        result[i*4+1] = mai0 * mb01 + mai1 * mb11 + mai2 * mb21 + mai3 * mb31;
        result[i*4+2] = mai0 * mb02 + mai1 * mb12 + mai2 * mb22 + mai3 * mb32;
        result[i*4+3] = mai0 * mb03 + mai1 * mb13 + mai2 * mb23 + mai3 * mb33;
    }
}


static void calcViewVolumePlanes (float planeEqs[][4])
{
    GLfloat ocEcMat[16], ecCcMat[16], ocCcMat[16];


    // Get the modelview and projection matrices
    glGetFloatv (GL_MODELVIEW_MATRIX, ocEcMat);
    glGetFloatv (GL_PROJECTION_MATRIX, ecCcMat);

    // ocCcMat transforms from OC (object coordinates) to CC (clip coordinates) 
    matrixConcatenate (ocCcMat, ocEcMat, ecCcMat);

    // Calculate the six OC plane equations. 
    planeEqs[0][0] = ocCcMat[3] - ocCcMat[0]; 
    planeEqs[0][1] = ocCcMat[7] - ocCcMat[4]; 
    planeEqs[0][2] = ocCcMat[11] - ocCcMat[8]; 
    planeEqs[0][3] = ocCcMat[15] - ocCcMat[12]; 

    planeEqs[1][0] = ocCcMat[3] + ocCcMat[0]; 
    planeEqs[1][1] = ocCcMat[7] + ocCcMat[4]; 
    planeEqs[1][2] = ocCcMat[11] + ocCcMat[8]; 
    planeEqs[1][3] = ocCcMat[15] + ocCcMat[12]; 

    planeEqs[2][0] = ocCcMat[3] + ocCcMat[1]; 
    planeEqs[2][1] = ocCcMat[7] + ocCcMat[5]; 
    planeEqs[2][2] = ocCcMat[11] + ocCcMat[9]; 
    planeEqs[2][3] = ocCcMat[15] + ocCcMat[13]; 

    planeEqs[3][0] = ocCcMat[3] - ocCcMat[1]; 
    planeEqs[3][1] = ocCcMat[7] - ocCcMat[5]; 
    planeEqs[3][2] = ocCcMat[11] - ocCcMat[9]; 
    planeEqs[3][3] = ocCcMat[15] - ocCcMat[13]; 

    planeEqs[4][0] = ocCcMat[3] + ocCcMat[2]; 
    planeEqs[4][1] = ocCcMat[7] + ocCcMat[6]; 
    planeEqs[4][2] = ocCcMat[11] + ocCcMat[10]; 
    planeEqs[4][3] = ocCcMat[15] + ocCcMat[14]; 

    planeEqs[5][0] = ocCcMat[3] - ocCcMat[2]; 
    planeEqs[5][1] = ocCcMat[7] - ocCcMat[6]; 
    planeEqs[5][2] = ocCcMat[11] - ocCcMat[10]; 
    planeEqs[5][3] = ocCcMat[15] - ocCcMat[14]; 
}




void cameraInfoManager::calculateClippingEquations(){
	
	for (int i = 0; i < NUM_CAM_POSITIONS; i++){			
		
		
		/*
			float aspectRatio    	=  rectPaneM->w / rectPaneM->h;
	float halfFovRad     	=  DEG_TO_RAD * FIELD_OF_VIEW_ANGLE / 2.0;
	float theTan				=  tanf (halfFovRad);
	float cameraDistance		=  (rectPaneM->h / 2.0) / theTan;
	float cameraNear  		=  cameraDistance / 10.0;
	float cameraFar      	=  cameraDistance * 10.0;
	
	float wd2            	=  cameraNear * theTan;
	float ndfl           	=  cameraNear / cameraDistance;
	float top            	=  wd2;
	float bottom         	= -wd2;
	float left  				= -aspectRatio * wd2;
	float right 				=  aspectRatio * wd2;	
	
	//--------------------------------
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(rectPaneM->x, rectPaneM->y, rectPaneM->w, rectPaneM->h);
	glFrustum(left,right,bottom,top, cameraNear, cameraFar);
	glMatrixMode(GL_MODELVIEW);
	glDrawBuffer(GL_BACK_LEFT);
	glLoadIdentity();

	// set the camera position.
	acVec3f *pos = eyePosition->pos;
	acVec3f *at  = eyePosition->at;
	acVec3f *up  = eyePosition->up;
	gluLookAt( pos->x, pos->y, pos->z, 
				  at->x,  at->y,  at->z,
				  up->x,  up->y,  up->z);
	
	glPushMatrix();
	draw(PANE_MONO, rectPaneM->w, rectPaneM->h, GLOBAL_ALPHA); // simulation rendered here.
	glPopMatrix(); 	
		
		*/
		
		
		acVec3f temp1 = camInputs[i].pts[1] - camInputs[i].pts[0];
		acVec3f temp2 = camInputs[i].pts[2] - camInputs[i].pts[1];		
		float mazoEyeX = temp1.length() / 2.0;
		float mazoEyeY = temp2.length() / 2.0;
		float halfFov = PI * 60.0f / 360.0;
		float theTan = tanf(halfFov);
		float mazoDist = mazoEyeY / theTan;
		float mazoNearDist = mazoDist / 10.0;
		float mazoFarDist = mazoDist * 10.0;
		float mazoAspect = (float)temp1.length()/temp2.length();
		
		float wd2            	=  mazoNearDist * theTan;
		float ndfl           	=  mazoNearDist / mazoDist;
		float top            	=  wd2;
		float bottom         	= -wd2;
		float left  				= -mazoAspect * wd2;
		float right 				=  mazoAspect * wd2;	
		

		
		 glMatrixMode (GL_PROJECTION); 
		 glLoadIdentity (); 
	    glViewport (0, 0, temp1.length(), temp2.length());       
	    glFrustum(left,right,bottom,top, mazoNearDist, mazoFarDist);

    	 
    	 //gluPerspective (50., (float)w/(float)h, 5., 20.);
    	 //gluPerspective(cams[i].fieldOfView, mazoAspect, mazoNearDist, mazoFarDist);
		
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity ();		
		gluLookAt (cams[i].pos.x, cams[i].pos.y, cams[i].pos.z,
	      cams[i].at.x, cams[i].at.y, cams[i].at.z,
	      cams[i].up.x, cams[i].up.y, cams[i].up.z);
	   calcViewVolumePlanes(camClipEqs[i].planeEqs);	
		
	}
	
}


   

 		

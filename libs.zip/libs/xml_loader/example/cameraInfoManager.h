
#ifndef _CAM_INFO_MANAGER
#define _CAM_INFO_MANAGER

#include "acu.h"
#include "acApp.h"
#include "acVec3f.h"
#include "MetaConstants.h"
#include "cameraInfo.h"
#include "BerlinPacket.h"
#include "ParamIO.h"


typedef struct camInput{
	acVec3f pts[4]; 
	float fov;
};

typedef struct camClippinEq{
	float planeEqs[6][4];
};

#define distanceFromPlane(peq,p) \
    ((peq)[0]*(p)[0] + (peq)[1]*(p)[1] + (peq)[2]*(p)[2] + (peq)[3])


class cameraInfoManager {

	public:
	
 		cameraInfoManager();
 		void bogusCamInfo();
 		void loadCamInfo();
 		void convertCamInputIntoCams();
 		
 		void calculateClippingEquations();
 		
 		void fillPacket( berlinPacket * BP);
 		cameraInfo cams[NUM_CAM_POSITIONS];
 		camClippinEq camClipEqs[NUM_CAM_POSITIONS];
 		// a test
 		int culled (int camNum, sgBbox sb);
 		camInput box;
 		camInput camInputs[NUM_CAM_POSITIONS];
 		cameraInfo CP;
 	private:
		
		

};


#endif


#include "ofSampleSoundSystem.h"


// ---------------------------------------------------------------------------- 
ofSampleSoundSystem::ofSampleSoundSystem( const int mixRate, const bool bSpectrum ){

	FSOUND_Init( mixRate, 32, 0 );
	useSpectrum( bSpectrum );

}

// ---------------------------------------------------------------------------- 
ofSampleSoundSystem *ofSampleSoundSystem::createSoundSystem( const int mixRate, const bool useSpectrum )
{
	ofSampleSoundSystem *soundSystem = new ofSampleSoundSystem( mixRate, useSpectrum );
	return soundSystem;
}


// ---------------------------------------------------------------------------- 
ofSampleSoundSystem::~ofSampleSoundSystem( ){
	
	FSOUND_Close( );

}

// ---------------------------------------------------------------------------- 
void ofSampleSoundSystem::play(ofSampleSound *sound ){

	if (sound->bLoop == true){
		FSOUND_StopSound(sound->channel);
	}
	
	int channel = FSOUND_PlaySound(FSOUND_FREE, sound->samp);
		
	sound->internalFreq = FSOUND_GetFrequency(channel);
	
	
	FSOUND_SetVolume(channel, (int)(sound->volume*255.0f));
	FSOUND_SetPan(channel, (int)(sound->pan*255.0f));
	FSOUND_SetPaused(channel, sound->bPaused);
	FSOUND_SetFrequency(channel, sound->internalFreq * sound->speed);
	FSOUND_SetLoopMode(channel, (sound->bLoop == true) ? FSOUND_LOOP_NORMAL : FSOUND_LOOP_OFF);
	
	sound->channel = channel;
	
}

// ---------------------------------------------------------------------------- 
void ofSampleSoundSystem::stop(ofSampleSound *sound ){
	
	FSOUND_StopSound(sound->channel);

}

// ---------------------------------------------------------------------------- 
void ofSampleSoundSystem::useSpectrum( const bool useSpectrum ){
    FSOUND_DSP_SetActive( FSOUND_DSP_GetFFTUnit( ), useSpectrum );
}

// ---------------------------------------------------------------------------- 
void ofSampleSoundSystem::getSpectrum( float *bufferToFill, const int numberOfBars ){

    const float *spectrum = FSOUND_DSP_GetSpectrum( );

    const float freqPerBand = 512.0f / ( (float) numberOfBars );

    for ( int i = 0; i < numberOfBars; ++i )
    {
        int offset = (int) ( ( (float) i ) * freqPerBand );
        
        float spectrumValue = spectrum[ offset ] * 64.0f;
        if ( spectrumValue > 1.0f )
        {
            spectrumValue = 1.0f;
        }

        bufferToFill[ i ] = spectrumValue;
    }
}

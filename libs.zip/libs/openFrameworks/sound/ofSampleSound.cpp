
#include "ofSampleSound.h"		
		
		
ofSampleSound::ofSampleSound(){

	bLoop = false;
	bLoadedOk = false;
	channel = -1;				
	pan = false;					
	volume = 1.0f;
	internalFreq = 44100;   // <- this is problematic?
	speed = 1;
	bPaused = false;
}



void ofSampleSound::loadSound(char * fileName){
	samp = FSOUND_Sample_Load(FSOUND_UNMANAGED, fileName, FSOUND_NORMAL, 0, 0);
	
}


void ofSampleSound::setVolume(float vol){
	FSOUND_SetVolume(channel, (int)(vol*255.0f));
	volume = vol;
}

void ofSampleSound::setPan(float p){
	FSOUND_SetPan(channel, (int)(p*255.0f));
	pan = p;
}

void ofSampleSound::setPaused(bool bP){
	FSOUND_SetPaused(channel, bP);
	bPaused = bP;
}

void ofSampleSound::setSpeed(float spd){
	FSOUND_SetFrequency(channel, internalFreq * spd);
	speed = spd;
}

void ofSampleSound::setLoop(bool bLp){
	FSOUND_SetLoopMode(channel, (bLp == true) ? FSOUND_LOOP_NORMAL : FSOUND_LOOP_OFF);
	bLoop = bLp;
}

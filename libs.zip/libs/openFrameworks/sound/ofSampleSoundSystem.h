

#ifndef _OF_SOUND_SYSTEM
#define _OF_SOUND_SYSTEM

#include "ofConstants.h"
#include "fmod.h"
#include "ofSampleSound.h"
// ---------------------------------------------------------------------------- SOUND SYSTEM FMOD

class ofSampleSoundSystem{	

	public:

		
		static  ofSampleSoundSystem* createSoundSystem( const int mixRate, const bool useSpectrum);
		~ofSampleSoundSystem( );
		
		
		void useSpectrum( const bool useSpectrum );
		void getSpectrum( float *bufferToFill, const int numberOfBars );
		ofSampleSoundSystem( const int mixRate, const bool useSpectrum );

		void play( ofSampleSound *sound );
		void stop( ofSampleSound *sound );

	private:
	
	

  


};

#endif // _OF_SOUND_SYSTEM

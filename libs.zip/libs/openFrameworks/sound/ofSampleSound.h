

#ifndef _OF_SAMPLE_SOUND
#define _OF_SAMPLE_SOUND

#include "fmod.h"

// ---------------------------------------------------------------------------- SOUND SYSTEM FMOD

class ofSampleSound{	

	public:

		
		ofSampleSound();

		void  loadSound(char * fileName);  					// use this for short samples.
		
		//TO DO :
		//void  loadSoundForStreaming(char * fileName);   // use this for long MP3s, etc... can even be a URL...
		
		void 	setVolume(float vol);
		void 	setPan(float vol);
		void 	setSpeed(float vol);
		void  setPaused(bool bP);
		void  setLoop(bool bLp);
		
		bool 	bLoop;
		bool 	bLoadedOk;
		bool  bPaused;
		int channel;				// in Fmod, what channel am I playing on?
		float pan;					// 0 - 1
		float volume;				// 0 - 1
		float internalFreq;		// 44100 ?
		float speed;				// -n to n, 1 = normal, -1 backwards
		
		FSOUND_SAMPLE  * samp;
			// to do pt in sample, etc
		
	private:


};

#endif // _OF_SAMPLE_SOUND

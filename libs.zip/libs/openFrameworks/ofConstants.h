/************************************************************
																				
OpenFrameworks Library												
																			
File: 				ofConstants.h															
Description: 		constants, h file stuff, #define multi OS trickery  										
																				
Notes: 																	
PI, min, max, etc, etc

																				
************************************************************/

#ifndef OF_CONSTANTS
#define OF_CONSTANTS



//#define TARGET_WIN32
#define TARGET_OSX


#ifdef TARGET_WIN32
	#include <windows.h>
	#include "glut.h"
#endif
	
#ifdef TARGET_OSX
	#include <GLUT/glut.h>
#endif





// core: ---------------------------
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#ifndef PI
	#define PI       3.14159265358979323846
#endif

#ifndef TWO_PI
	#define TWO_PI   6.28318530717958647693
#endif


#ifndef M_TWO_PI
	#define M_TWO_PI   6.28318530717958647693
#endif
	


#ifndef FOUR_PI
	#define FOUR_PI 12.56637061435917295385
#endif

#ifndef HALF_PI
	#define HALF_PI  1.57079632679489661923
#endif

#ifndef DEG_TO_RAD
	#define DEG_TO_RAD (PI/180.0)
#endif

#ifndef RAD_TO_DEG
	#define RAD_TO_DEG (180.0/PI)
#endif

#ifndef MIN
	#define MIN(x,y) (((x) < (y)) ? (x) : (y))
#endif

#ifndef MAX
	#define MAX(x,y) (((x) > (y)) ? (x) : (y))
#endif

#ifndef ABS
	#define ABS(x) (((x) < 0) ? -(x) : (x))
#endif

#define 	OF_FILLED				0x01
#define 	OF_OUTLINE				0x02
#define  	CIRC_RESOLUTION		    22				// 22 pts



#define OF_WINDOW 			0
#define OF_FULLSCREEN 		1

// these are in the "ofAppRunner.cpp" based on the various windowing options.
//--------------------------------------
void 	ofGetWindowSize( int * w, int * h);
float 	ofGetTimef();
int 	ofGetTimeMillis();

#endif

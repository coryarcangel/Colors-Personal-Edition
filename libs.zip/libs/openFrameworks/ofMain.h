#ifndef OF_MAIN_H
#define OF_MAIN_H

#include "ofConstants.h"

// math/util
#include "ofMath.h"
#include "ofUtils.h"
#include "ofVec3f.h"

// graphics
#include "ofImgTex.h"
#include "ofFont.h"
#include "ofTTFfont.h"
#include "ofGeom.h"

// app
#include "ofSimpleApp.h"
#include "ofAppRunner.h"

#endif

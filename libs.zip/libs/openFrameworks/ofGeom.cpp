
#include "ofGeom.h"



//----------------------------------------------------------
// static 
GLuint precachedCircle;
static float drawMode = OF_FILLED;
static bool bSetupCircle = false;
float bgColor[4] = {0,0,0,0};
//----------------------------------------------------------


//----------------------------------------------------------
float * ofBgColorPtr(){
	return bgColor;
}

//----------------------------------------------------------
void ofSetBgColor(float r, float g, float b, float a){
	bgColor[0] = r;
	bgColor[1] = g;
	bgColor[2] = b;
	bgColor[3] = a;
}

//----------------------------------------------------------
void ofNoFill(){
	drawMode = OF_OUTLINE;
};

//----------------------------------------------------------
void ofFill(){
	drawMode = OF_FILLED;
};

//----------------------------------------------------------
void setupCircle(){

	precachedCircle = glGenLists(1);
	glNewList(precachedCircle, GL_COMPILE);


	float angle = 0.0f;
	float angleAdder = M_TWO_PI / (float)CIRC_RESOLUTION;
	
	for (float i = 0; i < CIRC_RESOLUTION; i++){
		glVertex2f( cos(angle), sin(angle));
		angle += angleAdder;
	}
	  
	glEndList();

	bSetupCircle = true;
}

//----------------------------------------------------------
void ofSquare(float x,float y, float w){
	
	glBegin( (drawMode == OF_FILLED) ? GL_POLYGON : GL_LINE_LOOP);   	
		glVertex2f(x,y);
		glVertex2f(x,y+w);
		glVertex2f(x+w,y+w);
		glVertex2f(x+w,y);
	glEnd();
	
}

//----------------------------------------------------------
void ofTriangle(float x1,float y1,float x2,float y2,float x3, float y3){
	
	
	glBegin( (drawMode == OF_FILLED) ? GL_TRIANGLES : GL_LINE_LOOP);   	
		
		glVertex2f(x1,y1);
		glVertex2f(x2,y2);
		glVertex2f(x3,y3);
		
	
	glEnd();
	
}

//----------------------------------------------------------
void ofCircle(float x,float y, float radius){
		
		if (!bSetupCircle) setupCircle();

		glPushMatrix();
		glTranslatef(x, y, 0);
		glScalef(radius, radius, 1);
		
		glBegin( (drawMode == OF_FILLED) ? GL_POLYGON : GL_LINE_LOOP);   	
		glCallList(precachedCircle);
		glEnd();
		glPopMatrix();
}

//----------------------------------------------------------
void ofEllipse(float x, float y, float width, float height){
			
		
		glPushMatrix();
		glTranslatef(x, y, 0);
		glScalef(width, height, 1);
		
		glBegin( (drawMode == OF_FILLED) ? GL_POLYGON : GL_LINE_LOOP);   	
		glCallList(precachedCircle);
		glEnd();
		
		glPopMatrix();
	
}

//----------------------------------------------------------
void ofLine(float x1,float y1,float x2,float y2){
		
		glBegin( GL_LINES ); 
			glVertex2f(x1,y1);
			glVertex2f(x2,y2);	
		glEnd();

}

//----------------------------------------------------------
void ofRect(float x,float y,float w,float h){
		
	
	glBegin( (drawMode == OF_FILLED) ? GL_QUADS : GL_LINE_LOOP);   	
		glVertex2f(x,y);
		glVertex2f(x+w,y);
		glVertex2f(x+w,y+h);
		glVertex2f(x,y+h);
	glEnd();


}


/*
//----------------------------------------------------------
void ofHuntForBlendFunc(float period, int defaultSid, int defaultDid){
	
	// created by g. levin in a late-night moment of brilliance
	// sets all possible (24) combinations of blend functions,
	// changing modes every period seconds. 
	
	int sfact[] = {
		GL_DST_COLOR, 
		GL_ONE_MINUS_DST_COLOR, 
		GL_SRC_ALPHA_SATURATE
	};
		
	int dfact[] = {
		GL_ZERO,
		GL_ONE,
		GL_SRC_COLOR,
		GL_ONE_MINUS_SRC_COLOR,
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA,
		GL_DST_ALPHA,
		GL_ONE_MINUS_DST_ALPHA
	};
	
	
	if ((defaultSid == -1) && (defaultDid == -1)) {

		int sid =  ((int)(glfwGetTime()*1000)/(8*(int)(period*1000)))%8;
		int did =  ( (int)(glfwGetTime()*1000)/(int)((period)*1000))%8;
		
		glEnable(GL_BLEND);
		glBlendFunc(dfact[sid], dfact[did]);
		printf("SRC %d	DST %d\n", sid, did);
		
	} else {
		glEnable(GL_BLEND);
		glBlendFunc(dfact[defaultSid], dfact[defaultDid]);
		
	}



}
*/

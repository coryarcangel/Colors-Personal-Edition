
#include "ofAppRunner.h"
#include <iostream>


//========================================================================
// static variables:
static ofSimpleApp * 		OFSAptr;
bool 						bMousePressed;
bool						bRightButton;
float 						mousex, mousey;
int							width, height;


//========================================================================
// callbacks:
#include "ofAppGlutGlue.h"	




//--------------------------------------
void ofGetWindowSize( int  * w, int *  h){
	*w = glutGet(GLUT_WINDOW_WIDTH);	
	*h = glutGet(GLUT_WINDOW_HEIGHT);	
}

//--------------------------------------
float ofGetTimef(){
      return (float)(glutGet(GLUT_ELAPSED_TIME))/1000.0f;
}

//--------------------------------------
int ofGetTimeMillis(){
    return (int)(glutGet(GLUT_ELAPSED_TIME));
}





//========================================================================
void run(int w, int h, int screenMode, ofSimpleApp * OFSA){
		
        int argc = 1;
  		char *argv = "openframeworks";
  		char **vptr = &argv;
		OFSAptr = OFSA;
		// init
		glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_ALPHA);
		glutInit(&argc, vptr);
		// window
		if (screenMode == OF_WINDOW)		glutInitWindowSize(w, h);
		glutCreateWindow("");
		if (screenMode == OF_FULLSCREEN) 	glutFullScreen();
		// callbacks
		glutMouseFunc(mouse_cb);
		glutMotionFunc(motion_cb);
		glutPassiveMotionFunc(passive_motion_cb);
		glutIdleFunc(idle_cb);
		glutDisplayFunc(display);
		glutKeyboardFunc(keyboard_cb);
		glutSpecialFunc(special_key_cb);
		OFSA->init();
		
		//printf ("cursor %i", GetCursor());
		glutMainLoop();
		
}


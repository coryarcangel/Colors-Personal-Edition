
#include "ofSimpleApp.h"


void ofSimpleApp::ofSetupScreen(){
	
	int w, h;
	ofGetWindowSize( &w, &h );
	float halfFov, theTan, screenFov, aspect;
	screenFov = 60.0f;
	
	float eyeX = (float)w / 2.0;
	float eyeY = (float)h / 2.0;
	halfFov = PI * screenFov / 360.0;
	theTan = tanf(halfFov);
	float dist = eyeY / theTan;
	float nearDist = dist / 10.0;	// near / far clip plane
	float farDist = dist * 10.0;
	aspect = (float)w/(float)h;
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(screenFov, aspect, nearDist, farDist);
	gluLookAt(eyeX, eyeY, dist, 
	eyeX, eyeY, 0.0, 0.0, 1.0, 0.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	
	
}


	

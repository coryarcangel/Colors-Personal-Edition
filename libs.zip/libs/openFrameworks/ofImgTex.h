#ifndef _IMAGE_TEXTURE_H_
#define _IMAGE_TEXTURE_H_

/************************************************************
																				
openFrameworks Library												
																			
File: 				ofImgTex.h															
Description: 		ofImageTexture class 					
																	
																																														
notes: 																	


// internalGlDataType = how the texture is stored in the card
// types include : GL_LUMINANCE, GL_RGB, etc
// glDataType = the type of data being uploaded

// in the construction, 
// if w, h are not powers of 2 you will not see anything!!!
// please read about opengl textures to understand why this is

// your w,h, in loadImageData must be <= the w/h you specify in the constructor...
// but they DONT have to be powers of 2
																				
************************************************************/





#include "ofConstants.h"

class ofImgTex {


	public :
		
		ofImgTex(int w, int h, int internalGlDataType);	 
		void loadImageData(unsigned char * data, int w, int h, int glDataType); 
		void renderTexture(int x, int y, int w, int h);
		float tex_t, tex_u;   

	private:		
	
		int tex_w, tex_h;
		GLuint * texName;

}; 

#endif

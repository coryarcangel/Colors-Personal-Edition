#include "ofUtils.h"




//--------------------------------------------------


static float timeNow, timeThen, fps;
static int zframes;
static float fpsBlur = 0.0f;


float ofGetFps() {

	// (a) get time
	
	timeNow = ofGetTimef();
	
	// (b) calculate and display FPS (frames per second)
	
	if( (timeNow-timeThen) > 1.0 || zframes == 0 ) {
 		fps = (double)zframes / (timeNow-timeThen);
      timeThen = timeNow;
		zframes = 0;
		fpsBlur = 0.93f * fpsBlur + 0.07f * fps;
  	}
  	zframes++;
  	
  	return fpsBlur;
  	
}


//--------------------------------------------------

// from nehe.gamedev.net lesson 43
int ofNextPow2 ( int a )
{
	int rval=1;
	while(rval<a) rval<<=1;
	return rval;
}




static int frameNum = 0;

// whole frame:
//--------------------------------------------------
void ofScreenCapRaw(){

	int w, h;
	ofGetWindowSize( &w, &h );
	char *ScreenImageBuffer = (char*)malloc(w*h*3);
	char *flippedScreenImageBuffer = (char*)malloc(w*h*3);
	char fileName [255];
	sprintf(fileName, "screen_grab__%ix%i__%0.4i.raw", w, h, frameNum++);
	FILE* OutputFile = fopen(fileName, "wb");
	glReadPixels(0,0,w,h,GL_RGB,GL_UNSIGNED_BYTE,ScreenImageBuffer);
	// need to flip image
	for (int i = 0; i < h; i++) {
		memcpy(flippedScreenImageBuffer+(sizeof(char)*i*w*3), ScreenImageBuffer+(sizeof(char)*(h-i)*w*3), sizeof(char)*w*3);
	}
	fwrite(flippedScreenImageBuffer,w*h*3,1,OutputFile);
	fclose(OutputFile);
	free(ScreenImageBuffer);
	free(flippedScreenImageBuffer);

}


// sub region of frame:
//--------------------------------------------------
void ofScreenCapRaw(int x, int y, int w, int h){
	
	int width = w;  // width of cap region
	int height = h;  // height of cap region
	int sw, sh;
	// bounds checking here -----
	ofGetWindowSize( &sw, &sh );
	if (width+x > sw) width = sw-x;
	if (height+y > sh) height = sh-y;

	char *ScreenImageBuffer = (char*)malloc(width*height*3);
	char *flippedScreenImageBuffer = (char*)malloc(width*height*3);
	char fileName[255];
	sprintf(fileName, "screen_grab__%ix%i__%0.4i.raw", width, height, frameNum++);
	FILE* OutputFile = fopen(fileName, "wb");
	glReadPixels(x,y,width,height,GL_RGB,GL_UNSIGNED_BYTE,ScreenImageBuffer);
	// need to flip image
	for (int i = 0; i < height; i++) {
		memcpy(flippedScreenImageBuffer+(sizeof(char)*i*width*3), ScreenImageBuffer+(sizeof(char)*(height-i)*width*3), sizeof(char)*width*3);
	}
	fwrite(flippedScreenImageBuffer,width*height*3,1,OutputFile);
	fclose(OutputFile);
	free(ScreenImageBuffer);
	free(flippedScreenImageBuffer);

}

//--------------------------------------------------
//from www.easyrgb.com/math.php?MATH=M21#text21
void ofHsbToRgb(GLfloat *hsb, GLfloat *rgb) {

	if ( hsb[1] == 0 )                       
	{
	   rgb[0] = hsb[2] * 255;
	   rgb[1] = hsb[2] * 255;
	   rgb[2] = hsb[2] * 255;
	}
	else
	{
	  float var_h = hsb[0] * 6;
	  float var_i = floor( var_h ) ;            //Or ... var_i = floor( var_h )
	  float var_1 = hsb[2] * ( 1 - hsb[1] );
	  float var_2 = hsb[2] * ( 1 - hsb[1] * ( var_h - var_i ) );
	  float var_3 = hsb[2] * ( 1 - hsb[1] * ( 1 - ( var_h - var_i ) ) );


	   if      ( var_i == 0 ) { rgb[0] = hsb[2]     ; rgb[1] = var_3      ; rgb[2] = var_1;   }
	   else if ( var_i == 1 ) { rgb[0] = var_2      ; rgb[1] = hsb[2]     ; rgb[2] = var_1;   }
	   else if ( var_i == 2 ) { rgb[0] = var_1      ; rgb[1] = hsb[2]     ; rgb[2] = var_3;   }
	   else if ( var_i == 3 ) { rgb[0] = var_1      ; rgb[1] = var_2      ; rgb[2] = hsb[2];  }
	   else if ( var_i == 4 ) { rgb[0] = var_3      ; rgb[1] = var_1      ; rgb[2] = hsb[2];  }
	   else                   { rgb[0] = hsb[2]     ; rgb[1] = var_1      ; rgb[2] = var_2;   }

	   rgb[0];                  
	   rgb[1];
	   rgb[2];
	}
}


//--------------------------------------------------
void ofRgbToHsb(GLfloat *hsb, GLfloat *rgb)
{

	float var_R =  rgb[0];                    
	float var_G =  rgb[1];
	float var_B =  rgb[2];

	//find min
	float var_Min = 0;
	if(var_R < var_G)
	{
		 ( var_R < var_B ) ? var_Min = var_R : var_Min = var_B;
	}
	else ( var_G < var_B ) ? var_Min = var_G : var_Min = var_B;

	// find max
	float var_Max = 0;    
	if(var_R > var_G)
	{
		 ( var_R > var_B ) ? var_Max = var_R : var_Max = var_B;
	}
	else ( var_G > var_B ) ? var_Max = var_G : var_Max = var_B;	
	
		
	float del_Max = var_Max - var_Min;            //Delta RGB value 

	hsb[2] = var_Max;

	if ( del_Max == 0 )                     //This is a gray, no chroma...
	{
	   hsb[0] = 0;                                //hsb[0]hsb[1]V results = 0 � 1
	   hsb[1] = 0;
	}
	else                                    //Chromatic data...
	{
	   hsb[1] = del_Max / var_Max;

	   float del_R = ( ( ( var_Max - var_R ) / 6 ) + ( del_Max / 2 ) ) / del_Max;
	   float del_G = ( ( ( var_Max - var_G ) / 6 ) + ( del_Max / 2 ) ) / del_Max;
	   float del_B = ( ( ( var_Max - var_B ) / 6 ) + ( del_Max / 2 ) ) / del_Max;

	   if      ( var_R == var_Max ) hsb[0] = del_B - del_G;
	   else if ( var_G == var_Max ) hsb[0] = ( 1 / 3 ) + del_R - del_B;
	   else if ( var_B == var_Max ) hsb[0] = ( 2 / 3 ) + del_G - del_R;

	   if ( hsb[0] < 0 ) ; hsb[0] += 1;
	   if ( hsb[0] > 1 ) ; hsb[0] -= 1;
	}

}
//--------------------------------------------------






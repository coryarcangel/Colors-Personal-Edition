/************************************************************/
//																				//
//	OpenFrameworks Library												//
//																				//
//	File: ofMathLibrary.h												//
//	Description: 	Generic Math Functionality						//
//						Main File of the Math Library					//
//																				//
//	Last Modified: 2004.11.03											//
//	Creator: Clay Johnson												//
//	Last Modified By: Clay Johnson									//
//																				//
//	Notes: 																	//
//
// for fast things look here: http://musicdsp.org/archive.php?classid=5#115
//																			//
/************************************************************/












#ifndef _OF_MATH_H
#define _OF_MATH_H


#include "ofMain.h"


// definitions ------------------------



// functions --------------------------

// --------------------------------------------------- //
// Simply seeds the random number generator with the time
// Takes in nothing
// Returns a signed float

void ofSeedRandom();

// --------------------------------------------------- //
// Returns a random number between two floats
// Takes in two floats
// Returns a signed float

float ofSimpleRandomSF(float x, float y);

// --------------------------------------------------- //
// Returns a random number between two floats
// Takes in two floats
// Returns a signed int

int ofSimpleRandomSI(float x, float y);

// --------------------------------------------------- //
// Returns a random number between -1 and 1
// Takes in nothing
// Returns a signed float

float ofRandomF();

// --------------------------------------------------- //
// Returns a random number between 0 and 1
// Takes in nothing
// Returns an unsigned float

float ofRandomUF();

#endif

/************************************************************
																				
OpenFrameworks Library												
																			
File: ofUtils.h															
Description: 	Generic Util Functionality						
					Main File of the Util Library													


Last Modified: 2005.07.29											
Last Modified By: Zachary Lieberman																												
																				
Notes: 																	

2005.06.21 - (theo) switched hsbrgb code
2005.07.29 - (zach) added (per theo's request) interpolation on fps()


// to do:
// add output raw, input raw (for setpixel like things)

																	
************************************************************/



#ifndef _OF_UTIL
#define _OF_UTIL

// includes ---------------------------


#include "ofConstants.h"



// definitions ------------------------


// functions --------------------------

// --------------------------------------------------- //
// Frames Per Second call
// returns FPS as a float

float 	ofGetFps(void);
int 		ofReadInt(FILE *fp);
// 	read an int out of file, perform endian swap if needed



int 	ofNextPow2( int input);


void 	ofScreenCapRaw();
void 	ofScreenCapRaw(int x, int y, int w, int h);
void 	ofHsbToRgb(GLfloat *hsb, GLfloat *rgb); //hsv in format H (0-360.0/360.0) | S (0-100/100.0) | V (0-100/100.0)
void	ofRgbToHsb(GLfloat *rgb, GLfloat *hsb); //rgb in opengl format


#endif

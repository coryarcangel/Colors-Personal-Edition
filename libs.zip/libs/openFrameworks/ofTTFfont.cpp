#include "ofTTFfont.h"




//===========================================================================
ofTTFfont::ofTTFfont(const char *filename, int fontsize) {
  	ofTTFont_texW = 64;
  	ofTTFont_texH = 64;
  	FT_FONT_SIZE = (fontsize > 0) ? fontsize : 48;
  	
	int i;
	bLoadedOk = false;

	FT_Library library;
	if (FT_Init_FreeType( &library )){
		printf("PROBLEM WITH FT lib \n");
		return;
	}

	FT_Face face;

	if (FT_New_Face( library, filename, 0, &face )) {
		return;
	}

	
	FT_Set_Char_Size( face, FT_FONT_SIZE << 6, FT_FONT_SIZE << 6,96,96);
	mboxY = (face->height) >> 6;

	////printf("lineheight = %f \n", face->height);
	// load this char set - 0-numChars
	numChars = NUM_CHARACTERS_TO_LOAD;	
	// get the character properties:
	cps       = new charProps[numChars];
	texNames  = new GLuint[numChars];
	charAreas = new float[numChars];
	
	glGenTextures(numChars, texNames);
	
	//--------------------- load each char -----------------------
	
	int largest_texW = 0;
	int largest_texH = 0;
	
	for (int i = 0 ; i < numChars; i++){
	
		if(FT_Load_Glyph( face, FT_Get_Char_Index( face, (unsigned char)i ), FT_LOAD_DEFAULT )){
			printf("errora with %i \n", i);
		}
	
		//Move the face's glyph into a Glyph object.
    	FT_Glyph glyph;
    	if(FT_Get_Glyph( face->glyph, &glyph )){
			printf("errorb with %i \n", i);
		}
	
	
		//Convert the glyph to a bitmap.
		FT_Glyph_To_Bitmap( &glyph, ft_render_mode_normal, 0, 1 );
	   FT_BitmapGlyph bitmap_glyph = (FT_BitmapGlyph)glyph;

		//This reference will make accessing the bitmap easier
		FT_Bitmap& bitmap=bitmap_glyph->bitmap;

		//Use our helper function to get the widths of
		//the bitmap data that we will need in order to create
		//our texture.
	
		//printf("char = %c, width = %i \n", (unsigned char)i, bitmap.width);
		//printf("%f   %f  \n", (float)bitmap_glyph->top, (float)bitmap.rows);	
		
		int width  = ofNextPow2( bitmap.width );
		int height = ofNextPow2( bitmap.rows );;
		if (width > largest_texW)  { largest_texW = width;}
		if (height > largest_texH) { largest_texH = height;}
		
		cps[i].value 			= i;
		cps[i].height 			= bitmap_glyph->top;
		cps[i].width 			= bitmap.width;
		cps[i].setWidth 		= face->glyph->advance.x >> 6;
		cps[i].topExtent 		= bitmap.rows;
		cps[i].leftExtent		= bitmap_glyph->left;
		
		// texture internals
		cps[i].tTex				= (float)bitmap.width / (float)width;
		cps[i].vTex				= (float)bitmap.rows /  (float)height;
		
		// Allocate Memory For The Texture Data.
		GLubyte* expanded_data = new GLubyte[ 2 * width * height];

		// Here We Fill In The Data For The Expanded Bitmap.
		// Notice That We Are Using A Two Channel Bitmap (One For
		// Channel Luminosity And One For Alpha), But We Assign
		// Both Luminosity And Alpha To The Value That We
		// Find In The FreeType Bitmap. 
		// We Use The ?: Operator To Say That Value Which We Use
		// Will Be 0 If We Are In The Padding Zone, And Whatever
		// Is The FreeType Bitmap Otherwise.
		
		int nOnPixels = 0;
		for(int j=0; j <height;j++) {
			for(int k=0; k < width; k++){
				expanded_data[2*(k+j*width)] = 
					(k>=bitmap.width || j>=bitmap.rows) ?
					0 : 255;
				
				GLubyte pixval = 0; 
				expanded_data[2*(k+j*width)+1] = 
					(k>=bitmap.width || j>=bitmap.rows) ?
					0 : (pixval = bitmap.buffer[k + bitmap.width*j]);
					
				if (pixval > 0){
					nOnPixels++;
				}
			}
		}
		charAreas[i] = (float)nOnPixels;


		//Now we just setup some texture paramaters.
    	glBindTexture( GL_TEXTURE_2D, texNames[i]);
		
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		
		//Here we actually create the texture itself, notice
		//that we are using GL_LUMINANCE_ALPHA to indicate that
		//we are using 2 channel data.
		bool b_use_mipmaps = true;
		if (b_use_mipmaps){
   		gluBuild2DMipmaps(
   			GL_TEXTURE_2D, GL_LUMINANCE_ALPHA, width, height,
            GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, expanded_data);
		} else {
	    	glTexImage2D( GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA, width, height,
			   0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, expanded_data );
		}


		//With the texture created, we don't need to expanded data anymore
    	delete [] expanded_data;
   }
   ofTTFont_texW = (largest_texW > 0) ? largest_texW : 64;
   ofTTFont_texH = (largest_texH > 0) ? largest_texH : 64;
   
   for (int i=0; i<numChars; i++){
   	charAreas[i] /= (float)(ofTTFont_texW*ofTTFont_texH);
   }
   
	
	FT_Done_Face(face);
	FT_Done_FreeType(library);
  	bLoadedOk = true;
}


int ofTTFfont::ofNextPow2 ( int a )
{
	int rval=1;
	while(rval<a) rval<<=1;
	return rval;
}


float ofTTFfont::getDescent() {
  return (float)(cps['p'].height - cps['p'].topExtent) / (float)ofTTFont_texH;
}

float ofTTFfont::getHeight() {
  return (float)mboxY / (float)64;
}



float ofTTFfont::charHeight(int c) {
  return (float)cps[c].height / (float)ofTTFont_texH;
}

float ofTTFfont::charBitmapWidth(int c) {
  // width of the bitmap itself
  return (float)cps[c].width / (float)ofTTFont_texW;
}

float ofTTFfont::charBitmapHeight(int c) {
  // same as charHeight
  return (float)cps[c].height / (float)ofTTFont_texH;
}

float ofTTFfont::charTop(int c) {
  return -charHeight(c) + (float)(cps[c].topExtent) / (float)ofTTFont_texH;
}

float ofTTFfont::charLeftExtent(unsigned char c) {
  return (float)cps[(int)c].leftExtent / (float)ofTTFont_texW;
}

bool ofTTFfont::charExists(char c) {
	
  return true;
  //return ((c > 32) && (c < numChars));

}

float ofTTFfont::charArea (unsigned char c){
	return (charAreas[c]);
}


void ofTTFfont::drawChar(int c, float x, float y) {

  
  
  if (!charExists(c)){

   return;
	}

  int cu = c;
  
  
  float height  = charHeight(cu);
  float bwidth  = charBitmapWidth(cu);
  float top     = charTop(cu);
  float lextent = charLeftExtent(cu);
  
  float t = cps[cu].tTex;
  float v = cps[cu].vTex;
  
  

  if (glIsTexture(texNames[cu])) {
  
   /*acuNamedTexRectf(x, y+height, 
		     x+bwidth,  y-top,
		     texNames[cu], t,v);
  	*/
  	
  	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texNames[cu]);
	glNormal3f(0, 0, 1);
  	glBegin(GL_QUADS);
		glTexCoord2d(0,0); glVertex2f(x, y + height);
		glTexCoord2d(0,v); glVertex2f(x, y-top);
		glTexCoord2d(t,v); glVertex2f(x + bwidth,y-top);
		glTexCoord2d(t,0); glVertex2f(x + bwidth,y + height);
	glEnd();
  
  glDisable(GL_TEXTURE_2D);
  	
  	
  } else {

		printf("ofTTFONT - texture not bound for character \n");   
  }

}


float ofTTFfont::charWidth(unsigned char c) {
	return (float)(cps[c].setWidth) / (float)ofTTFont_texW;
	/*
	if (c == ' '){
		return charWidth ('n'); 
	} else {
		return (float)(cps[c].setWidth) / (float)ofTTFont_texW;
	}
	*/
  // width of the horizontal space char takes up
}


float ofTTFfont::stringWidth(char *s) {
    float wide = 0;
    float pwide = 0;
  
    while (*s != 0) {
      if (*s == '\n') {
			if (wide > pwide) pwide = wide;
			wide = 0;

      } else {
      	unsigned char c = (unsigned char)(s[0]);
      	float cw = charWidth(c);
      	if ((cw < 0.0) || (cw > 1.0)){ cw = charWidth('n');}
      	float ce = charLeftExtent(c);
			wide += cw;
			wide += ce;
      }
      s++;
    }
    return (pwide > wide) ? pwide : wide;
}

//=====================================================================
void ofTTFfont::drawString(char *c, float x, float y) {
    
    glPushMatrix();
    
    float startX = x;
    int index = 0;
    
    
    
    while (c[index] != 0) {
      
      int cy = (unsigned char)c[index];
      if (c[index] == '\n') {
			
			x = startX;
			y -= getHeight() * 1.2;
			//printf("adding leading\n");
      } else {
      		
      	x += charLeftExtent(cy);
			drawChar(cy, x, y);
			
			x += cps[cy].setWidth/ (float)ofTTFont_texW; //charWidth(cy);
      		
   	}
    	
    	index++;
    
    }
    glPopMatrix();
}




/*

//Create and initilize a freetype font library.
	FT_Library library;
	if (FT_Init_FreeType( &library )) 
		throw std::runtime_error("FT_Init_FreeType failed");

	//The object in which Freetype holds information on a given
	//font is called a "face".
	FT_Face face;

	//This is where we load in the font information from the file.
	//Of all the places where the code might die, this is the most likely,
	//as FT_New_Face will die if the font file does not exist or is somehow broken.
	if (FT_New_Face( library, fname, 0, &face )) 
		throw std::runtime_error("FT_New_Face failed (there is probably a problem with your font file)");

	//For some twisted reason, Freetype measures font size
	//in terms of 1/64ths of pixels.  Thus, to make a font
	//h pixels high, we need to request a size of h*64.
	//(h << 6 is just a prettier way of writting h*64)
	FT_Set_Char_Size( face, h << 6, h << 6, 96, 96);

	//Here we ask opengl to allocate resources for
	//all the textures and displays lists which we
	//are about to create.  
	list_base=glGenLists(200);
	glGenTextures( 200, textures );

	//This is where we actually create each of the fonts display lists.
	for(unsigned char i=0;i<200;i++)
		make_dlist(face,i,list_base,textures);

	//We don't need the face information now that the display
	//lists have been created, so we free the assosiated resources.
	FT_Done_Face(face);

	//Ditto for the library.
	FT_Done_FreeType(library);

*/




/*  NEW

 FILE *fp = fopen(filename, "rb");
  if (fp == NULL) {
   
   printf("can't find font \n");
    //sprintf(acuDebugStr, "Could not open font file %s", filename);
   // acuDebugString(ACU_DEBUG_PROBLEM);
    return;
  }

  // read the base font information
  numChars = ofReadInt(fp);
  numBits = ofReadInt(fp);
  mboxX = ofReadInt(fp);
  mboxY = ofReadInt(fp);
  baseHt = ofReadInt(fp);
  ofReadInt(fp);  // ignore 4 for struct;

  // allocate enough space for the character info
  
  cps = new charProps[numChars];
  // read the information about the individual characters
  for (i = 0; i < numChars; i++) {
    cps[i].value 			= ofReadInt(fp);
    cps[i].height 		= ofReadInt(fp);
    cps[i].width 			= ofReadInt(fp);
    cps[i].setWidth 		= ofReadInt(fp);
    cps[i].topExtent 	= ofReadInt(fp);
    cps[i].leftExtent	= ofReadInt(fp);
    ofReadInt(fp); // pointer, ignored
  }

  // read in the bitmap data
  //images = new unsigned char[numChars][64*64*4];
  images = new unsigned char*[numChars];
  for (i = 0; i < numChars; i++) {
    images[i] = new unsigned char[64*64*4];
    int bitmapSize =  cps[i].height *  cps[i].width;
    //printf("bitmap size is %d\n", bitmapSize);
    unsigned char *temp = new unsigned char[bitmapSize];
    fread(temp, bitmapSize, 1, fp);

    // convert the bitmap to an alpha channel
    int w =  cps[i].width;
    int h =  cps[i].height;
    for (int x = 0; x < w; x++) {
      for (int y = 0; y < h; y++) {
	int offset = (y*64 + x) * 4;
	images[i][offset + 0] = temp[(h-y-1)*w + x];;
	images[i][offset + 1] = temp[(h-y-1)*w + x];;
	images[i][offset + 2] = temp[(h-y-1)*w + x];;
	images[i][offset + 3] = temp[(h-y-1)*w + x];
	//printf((images[i][offset+3] > 128) ? "*" : ".");
      }
      //printf("\n");
    }
  }

  // build textures for each of the characters
  texNames = new GLuint[numChars];
  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
  //printf("numChars is %d\n", numChars);
  glGenTextures(numChars, texNames);
  //for (int m = 0; m < numChars; m++) {
  //printf("%d ", texNames[m]);
  //}
    
  for (i = 0; i < numChars; i++) {
    glBindTexture(GL_TEXTURE_2D, texNames[i]);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_INTENSITY, 64, 64, 0,
		 GL_RGBA, GL_UNSIGNED_BYTE, images[i]);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
  }

*/


/*
/*
	//So now we can create the display list
	glNewList(list_base+ch,GL_COMPILE);

	glBindTexture(GL_TEXTURE_2D,tex_base[ch]);

	//first we need to move over a little so that
	//the character has the right amount of space
	//between it and the one before it.
	glTranslatef(bitmap_glyph->left,0,0);

	//Now we move down a little in the case that the
	//bitmap extends past the bottom of the line 
	//(this is only true for characters like 'g' or 'y'.
	glPushMatrix();
	glTranslatef(0,bitmap_glyph->top-bitmap.rows,0);

	
	// t, v ;;;;;;;
	
	float	x=(float)bitmap.width / (float)width,
			y=(float)bitmap.rows / (float)height;

	//Here we draw the texturemaped quads.
	//The bitmap that we got from FreeType was not 
	//oriented quite like we would like it to be,
	//so we need to link the texture to the quad
	//so that the result will be properly aligned.
	glBegin(GL_QUADS);
	glTexCoord2d(0,0); glVertex2f(0,bitmap.rows);
	glTexCoord2d(0,y); glVertex2f(0,0);
	glTexCoord2d(x,y); glVertex2f(bitmap.width,0);
	glTexCoord2d(x,0); glVertex2f(bitmap.width,bitmap.rows);
	glEnd();
	glPopMatrix();
	glTranslatef(face->glyph->advance.x >> 6 ,0,0);


	//increment the raster position as if we were a bitmap font.
	//(only needed if you want to calculate text length)
	//glBitmap(0,0,0,0,face->glyph->advance.x >> 6,0,NULL);

	//Finnish the display list
	glEndList();
	


*/

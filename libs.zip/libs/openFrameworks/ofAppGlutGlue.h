
void display(void);
void mouse_cb(int button, int state, int x, int y);
void motion_cb(int x, int y);
void passive_motion_cb(int x, int y);
void idle_cb(void);
void keyboard_cb(unsigned char key, int x, int y);
void special_key_cb(int key, int x, int y) ;


//------------------------------------------------------------
void display(void){	
	ofGetWindowSize( &width, &height );        
	height = height > 0 ? height : 1;
	// set viewport, clear the screen
	glViewport( 0, 0, width, height );
	float * bgPtr = ofBgColorPtr();
	glClearColor(bgPtr[0],bgPtr[1],bgPtr[2], bgPtr[3]);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	OFSAptr->draw();
  	glutSwapBuffers();
    
}
//------------------------------------------------------------
void mouse_cb(int button, int state, int x, int y) {
  if (state == GLUT_DOWN) {
    OFSAptr->mouseDown(x, height - y, button);
  } else if (state == GLUT_UP) {
    OFSAptr->mouseUp(x, height - y, button);
  }
}

//------------------------------------------------------------
void motion_cb(int x, int y) {
  OFSAptr->mouseDrag((float)x, height - (float)y, 0);
}

//------------------------------------------------------------
void passive_motion_cb(int x, int y) {
 OFSAptr->mouseMove(x, height - y);
}

//------------------------------------------------------------
void idle_cb(void) {
  OFSAptr->idle();
   glutPostRedisplay();
}

//------------------------------------------------------------
void keyboard_cb(unsigned char key, int x, int y) {
  OFSAptr->keyDown(key);
  if (key == 27) std::exit(0);	// quit!
}

//------------------------------------------------------------
void special_key_cb(int key, int x, int y) {
  //acApp::theApp->specialKeyDown(key);
  // nothing yet, coming soon...
}

#ifndef OF_GEOM
#define OF_GEOM

/************************************************************
																				
OpenFrameworks Library												
																			
File: 			ofGeom.h															
Description: 	I make shapes							
																				
Last Modified: 2004.11.03											
Creator: Carlos Giffoni									
Last Modified By: 									
								
								
								
																				
Notes: 																	

this class handles the drawing of shapes, making is slightly easier 
for you to drawing things like circles, quads, ellipses, etc,

for example, in opengl, in order to draw a line, you need to write:

glBegin(GL_LINES);
	glVertex2f(0,0);
	glVertex2f(100,100);
glEnd();

we wrap those kinds of functions so that you can just write:

ofLine(0,0,100,100);

much simpler, huh?

the fill, noFill control how shapes are drawn.

currently, circle is pre-cached at 22 points, this is defined in constants.h
feel free to change that number and recompile,  we could also use some smartness, 
and have multiple resolutions of circles, etc.... anyone want to help?

ofHuntForBlendFunc is a helpful function which tries every opengl blend
combination.  call:

ofHuntForBlendFunc(1,-1,-1); 

and it'll try every combo (and print out the combos) every "1" second,

if you find a compbo you like (0,2) for example,
you can just call the function with :

ofHuntForBlendFunc(1,0,2); and, instead of trying out new combos, it does 
this one.


																				
************************************************************/


#include "ofConstants.h"


// bg color
float * ofBgColorPtr();
void ofSetBgColor(float r, float g, float b, float a);

// geometry 
void setup();
void ofSquare(float side,float x,float y);
void ofTriangle(float x1,float y1,float x2,float y2,float x3, float y3);
void ofCircle(float radius,float x,float y);
void ofEllipse(float width, float height, float x,float y);
void ofLine(float x1,float y1,float x2,float y2);
void ofRect(float x1,float y1,float w, float h);

// drawing options
void ofNoFill();
void ofFill();

void setupCircle();


// helpful functions
void ofHuntForBlendFunc(float period, int defaultSid, int defaultDid);


#endif

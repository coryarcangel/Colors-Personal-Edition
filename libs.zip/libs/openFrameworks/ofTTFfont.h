/************************************************************
																				
OpenFrameworks Library												
																			
File: ofTTFont.h															
Description: 	I load true type fonts to use w/ opengl									
																				
																				
Last Modified: 2004.11.03											
Creator: Zachary Lieberman											
Last Modified By: 										
																				
Notes: 																	

// GL_INTENSITY SEEMS THE BEST for internal texture format / blending modes
// - ZACH
// 
// can we investigate the FT_FONT_SIZE and options for small,
// non anti-aliased type ?
// need to spend some moments thinking about how free type renders type
// and how to pick good sizes, etc. 
// 
// 
																	
************************************************************/


#ifndef _OF_TTF_FONT_H_
#define _OF_TTF_FONT_H_

/*
#include "ofUtils.h"
#include "ofConstants.h"
*/
#include "ofFont.h"



// freetype:


//#include <ft2build.h>
//#include <freetype/freetype.h>
//#include <freetype/ftglyph.h>
//#include <freetype/ftoutln.h>
//#include <freetype/fttrigon.h>

//#include "ft2build.h"
//#include "freetype.h"
//#include "ftglyph.h"
//#include "ftoutln.h"
//#include "fttrigon.h"

					

typedef struct {

	int value;
	int height;
	int width;
	int setWidth;
	int topExtent;
	int leftExtent;
	
	float tTex;
	float vTex;		//0-1 pct of bitmap...
	
} charProps;


#define NUM_CHARACTERS_TO_LOAD		256			// ascii char set


class ofTTFfont : public ofFont{

public:
  

	ofTTFfont(const char *filename, int fontsize);
	bool	bLoadedOk;

	float 	getDescent();
  	float 	getHeight();
  	float 	charWidth(unsigned char c);
  	float 	charHeight(int c);
  	bool 		charExists(char c);
  	void 		drawChar(int c, float x, float y);
	float 	charArea(unsigned char c);
	float    charLeftExtent(unsigned char c);
	float charBitmapWidth(int c);
	float charBitmapHeight(int c);
	float charTop(int c);
	float charTopExtent(int c);
	
	//void 	ftLoadGlyph(			)
	
	virtual float 	stringWidth(char *s); 
	virtual void 	drawString(char *c, float x, float y);

	int ofNextPow2 ( int a );
	
	
	
protected:
	
	int FT_FONT_SIZE; 
	int numChars;
	int numBits;
	int mboxX;
	int mboxY;
	int baseHt;
	
	charProps * cps;	// properties for each character
	unsigned char **images;
	float  *charAreas;
	GLuint *texNames;



	
	int ofTTFont_texW;
	int ofTTFont_texH;
	
};


#endif


#ifndef _OF_SIMPLE_APP
#define _OF_SIMPLE_APP

#include "ofConstants.h"

class ofSimpleApp{
	
	public:
	
		ofSimpleApp(){}
		
		virtual void idle(){}
		virtual void init(){}
		virtual void draw(){}
		virtual void keyDown  (char c){}
		virtual void mouseMove( float x, float y ){}
		virtual void mouseDrag( float x, float y, int button ){}
		virtual void mouseDown( float x, float y, int button ){}
		virtual void mouseUp  ( float x, float y, int button ){}
		
		virtual void startSound (){}
		virtual void stopSound (){}
		
		
		void ofSetupScreen();
};

#endif	

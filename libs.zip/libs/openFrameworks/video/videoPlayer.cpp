
#include "videoPlayer.h"

videoPlayer::videoPlayer(){
}
void videoPlayer::fillBufferWithVideoData(unsigned char *){
}
void videoPlayer::goToTime(float pct){
}
void videoPlayer::getNextFrame(float pct){
}
void videoPlayer::grabFrame(){
}
void videoPlayer::close(){
}
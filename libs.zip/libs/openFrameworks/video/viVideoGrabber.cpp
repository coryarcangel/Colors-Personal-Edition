#include "viVideoGrabber.h"


//------------------------------------------------------------------
viVideoGrabber::viVideoGrabber (int w, int h) : videoGrabber(w,h){
	 VI = new videoInput();
	 VI->setPhyCon(0, VI_COMPOSITE); 
	 VI->setCaptureSize(0,w,h);
	
	 VI  ->setup(1);			// < this needs to change for multi camera! 
	
	 frame   = new unsigned char[VI->getSize(0)]; 
}

//------------------------------------------------------------------
void viVideoGrabber::fillBufferWithVideoData(unsigned char * buffer){
	memcpy(buffer,frame, VI->getSize(0));
}

//------------------------------------------------------------------
void viVideoGrabber::grabFrame(){
	VI->grabFrame(0, frame);
}

//------------------------------------------------------------------
void viVideoGrabber::close(){

}

/*
	videoInput * VI  = new videoInput();
	//VI  ->setPhyCon(VI_S_VIDEO);             //If you need to change the input
	//VI  ->setCaptureSize(0,320,240);		   //if you need a size other than the default
	VI  ->setup(1); //try to setup two cameras.

	unsigned char * frame   = new unsigned char[VI->getSize(0)]; //set the buffer to the size we are capturing at
	while(running)
	{			
		if(VI->grabFrame(0, frame))  //do something with the image
	}
	
	//use VI->getWidth(0) VI->getHeight(0) to get image dimensions,  VI->getSize(0) for image size 
*/

/*
	VI  = new videoInput();
	VI  ->setPhyCon(0, VI_S_VIDEO);
	VI  ->setCaptureSize(0,640,480);			 
	VI  ->setup(1);

*/
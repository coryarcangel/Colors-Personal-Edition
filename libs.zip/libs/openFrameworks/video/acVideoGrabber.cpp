/*




#include "acVideoGrabber.h"

acVideoGrabber::acVideoGrabber(){
	initVideo();
}

void acVideoGrabber::fillBufferWithVideoData(unsigned char * data){
	
	memcpy(data,  video->buffer, TOTAL_CAPTURED_IMAGE_SIZE);
	
}

unsigned char *  acVideoGrabber::returnDataPtr(){
	
	return video->buffer;
}

void acVideoGrabber::grabFrame(){
	
	video->grabFrame();
	
	
}

void acVideoGrabber::close(){

}





void acVideoGrabber::videoSettings(void)
{
}




void acVideoGrabber::initVideo(){
	video = new acVideo(CAPTURE_SIZE_W, CAPTURE_SIZE_H);
	if (!video->initialized){
		
		printf("---------------------------------------\n");
		printf("Hardware error: video grabber failed to initialize!\n");
		
		
	}
	video->start();
}



*/
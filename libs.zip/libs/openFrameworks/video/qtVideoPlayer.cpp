

#include "qtVideoPlayer.h"
#include <stdio.h>
#include <stdlib.h>


//---------------------------------------------------------------------------
qtVideoPlayer::qtVideoPlayer (char * fileName){
	loadMovie(fileName);
}

//---------------------------------------------------------------------------
qtVideoPlayer::qtVideoPlayer (){

	theMovie = nil;
	thePlayer = nil;
		
	w = 0;
	h = 0;  
	
	pctBlur = 0;    

}


//---------------------------------------------------------------------------
void qtVideoPlayer::fillBufferWithVideoData(unsigned char * data){
		

		
		#ifdef TARGET_WIN32
			memcpy(data, videoBuffer, totalImageSize);
		#endif
		
		#ifdef TARGET_OSX

			unsigned char * srcBase;
			unsigned char * trgBase;
			unsigned char * vidPtr = videoBuffer;
			
			int rowSize = w*4;	
			for (int i = 0; i < h; i++)
			{
				srcBase = vidPtr + i * rowSize + 1; //+1 makes it RGBA instead of ARGB - Hallalehuh!
				trgBase = data + i * rowSize;
				memcpy(  trgBase, srcBase, rowSize);
			}
			
		#endif
		
	
}

//---------------------------------------------------------------------------
void qtVideoPlayer::goToTime(float pct){
}

//---------------------------------------------------------------------------
void qtVideoPlayer::getNextFrame(float pct){
}


static int counter = 0;

//---------------------------------------------------------------------------
// zach -- how often should I call moviesTask?
// where is this documented?
void qtVideoPlayer::grabFrame(){
	counter++;
   MoviesTask(theMovie,0);
}

//---------------------------------------------------------------------------
void qtVideoPlayer::close(){
    DisposeMovie (theMovie);
    #ifdef TARGET_WIN32
		DisposeMovieDrawingCompleteUPP (myDrawCompleteProc);
    #endif
	ExitMovies ();             // Finalize Quicktime;
}


bool qtVideoPlayer::createMovieFromPath(char * path, Movie * movie)
{
	Boolean isdir;
	OSErr result = 0;
	FSSpec theFSSpec;
    FSRef fsref;
	short resRefNum = -1;	
	short actualResId = DoTheRightThing;

	
	#ifdef TARGET_WIN32
		result = NativePathNameToFSSpec (path, &theFSSpec, 0 /* flags */);
		if (result) { printf("NativePathNameToFSSpec failed %d\n", result); printf("ERROR LOADING MOVIE \n"); return false; }
	#endif
	#ifdef TARGET_OSX
		result = FSPathMakeRef((const UInt8*)path, &fsref, &isdir);
		if (result) { printf("FSPathMakeRef failed %d\n", result); printf("ERROR LOADING MOVIE \n"); return false; }
		result = FSGetCatalogInfo(&fsref, kFSCatInfoNone, NULL, NULL, &theFSSpec, NULL);
		if (result) { printf("FSGetCatalogInfo failed %d\n", result); printf("ERROR LOADING MOVIE \n"); return false; }
	#endif


	result = OpenMovieFile (&theFSSpec, &resRefNum, 0);
	if (result) { printf("OpenMovieFile failed %d\n", result); printf("ERROR LOADING MOVIE \n"); return false; }
	result = NewMovieFromFile (&theMovie, resRefNum, &actualResId, (unsigned char *) 0, 0, (Boolean *) 0);
	if (result) { printf("NewMovieFromFile failed %d\n", result); printf("ERROR LOADING MOVIE \n"); return false; }
	if (resRefNum != -1) CloseMovieFile (resRefNum);
	
	return true;

}

//---------------------------------------------------------------------------
bool qtVideoPlayer::loadMovie(char * name){

	
	int i;

	OSErr result = 0;
	short resRefNum = -1;
	
	#ifdef TARGET_WIN32
		InitializeQTML(0);
	#endif
	
	
	EnterMovies ();  // Initialize Quicktime  

	createMovieFromPath(name, &theMovie);
	
	GetMovieBox(theMovie, &rectMovie);
	
	rectMovie.right -= rectMovie.left;
	rectMovie.left -= rectMovie.left;
	rectMovie.bottom -= rectMovie.top;
	rectMovie.top -= rectMovie.top;
	
	SetMovieBox(theMovie, &rectMovie);
	
	w = rectMovie.right;
	h = rectMovie.bottom;
	
	totalImageSize = w * h * 4;
	
	// Create a buffer big enough to hold the video data, 
	// make sure the pointer is 32-byte aligned.
	videoBuffer = (unsigned char*)malloc(4 * w * h + 32);

	#ifdef TARGET_WIN32
		//QTNewGWorld(&offWorld, k32RGBAPixelFormat, &rectMovie, NULL, NULL, keepLocal);
		QTNewGWorldFromPtr (&offWorld, k32RGBAPixelFormat, &rectMovie, NULL, NULL, 0, videoBuffer, 4 * w);
	#endif
	#ifdef TARGET_OSX
		QTNewGWorldFromPtr (&offWorld, k32ARGBPixelFormat, &rectMovie, NULL, NULL, 0, videoBuffer, 4 * w);
	#endif
	
	SetGWorld (offWorld, NULL);
	SetMovieGWorld (theMovie, offWorld, nil);
	SetMovieActive (theMovie, true);
	GoToBeginningOfMovie( theMovie );
	
	SetMovieVolume(theMovie, 100);
	
	int loop = 1;
	

	SetMoviePlayHints(theMovie, hintsLoop, 1);
	SetMovieActiveSegment(theMovie, -1,-1);

	//<CORY> I have modified this loopstate from 0 to 2 
	//Shouldn't we be able to set this up when the movie loads in?
	int loopState = 2;
	//</CORY>
	
	TimeBase myTimeBase;
	long myFlags = 0L;

	if (theMovie == NULL)
		return false;

	myTimeBase = GetMovieTimeBase(theMovie);
	myFlags = GetTimeBaseFlags(myTimeBase);

	switch (loopState) {

		case 0:
			SetMoviePlayHints(theMovie, hintsLoop, hintsLoop);
			SetMoviePlayHints(theMovie, 0L, hintsPalindrome);
			myFlags |= loopTimeBase;
			myFlags &= ~palindromeLoopTimeBase;
			break;

		case 1:
			SetMoviePlayHints(theMovie, hintsLoop, hintsLoop);
			SetMoviePlayHints(theMovie, hintsPalindrome, hintsPalindrome);
			myFlags |= loopTimeBase;
			myFlags |= palindromeLoopTimeBase;
			break;

		case 2:
			default:
			myFlags &= ~loopTimeBase;
			myFlags &= ~palindromeLoopTimeBase;
			SetMoviePlayHints(theMovie, 0L, hintsLoop | 
			hintsPalindrome);
			break;
	}

	SetTimeBaseFlags(myTimeBase, myFlags);
	StartMovie(theMovie);
	
	return true;
}


//---------------------------------------------------------------------------
void qtVideoPlayer::setMoviePct(float pct){
	
	
 	TimeRecord tr;
	tr.base = GetMovieTimeBase(theMovie);
	long total = GetMovieDuration( theMovie );
	long newPos = (long)((float)total * pct);	
	SetMovieTimeValue(theMovie, newPos);
	
	//info:
	//http://viewcvs.osafoundation.org/chandler/trunk/internal/wx/src/msw/mediactrl.cpp?rev=6281&view=markup
}	



//---------------------------------------------------------------------------
float qtVideoPlayer::getMovieDuration(){
	return GetMovieDuration (theMovie) / (double) GetMovieTimeScale (theMovie);	
}


//<CORY>
//---------------------------------------------------------------------------
float qtVideoPlayer::getMovieTimeAPI(){
	return GetMovieTime (theMovie, nil);
}
//---------------------------------------------------------------------------
float qtVideoPlayer::getMovieTimeScaleAPI(){
	return GetMovieTimeScale (theMovie);
}
//---------------------------------------------------------------------------
float qtVideoPlayer::getMovieDurationAPI(){
	return GetMovieDuration (theMovie);	
}
//</CORY>


//---------------------------------------------------------------------------
float qtVideoPlayer::getMoviePct(){

	// can be precached: 
	long total 		= GetMovieDuration( theMovie );
	long current 	= GetMovieTime( theMovie, nil);
			 
	
	float pct = ((float)current/(float)total);
	
	pctBlur 	= 0.2f * pctBlur 	+ 0.2f * pct;
	
	if (lastTime != current){
		
		float timeNow =0;// glueGetTime();
		durationTime = timeNow - lastTimeStamp;
		durationPct = pct - ((float)lastTime /(float)total);
		lastTimeStamp = timeNow;
		
		
	} else {
	
		// attempt to do a subtime here:  // this is strange, but works....
		//float cur_m_lastTimeStamp = glueGetTime() - lastTimeStamp;
		float cur_m_lastTimeStamp = 0 - lastTimeStamp;
		if (durationTime < 0.0001) durationTime = 0.0001;
		float pctTemp = cur_m_lastTimeStamp / durationTime;
		pctTemp = MIN(1.0f, pctTemp);
		lastTime = current;
		return  pct + pctTemp * durationPct;
		
	}
	
	lastTime = current;
	return  pct;
}

//---------------------------------------------------------------------------
void 	qtVideoPlayer::setSpeed(float _speed){
	speed = _speed;
	SetMovieRate(theMovie, X2Fix(speed));
}

float qtVideoPlayer::getSpeed(){
	return speed;
}
//http://developer.apple.com/documentation/QuickTime/INMAC/QT/iqMovieToolbox.34.htm
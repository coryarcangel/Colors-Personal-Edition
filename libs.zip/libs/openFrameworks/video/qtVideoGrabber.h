#ifndef _QT_VIDEO_GRABBER
#define _QT_VIDEO_GRABBER




// windows / mac keep qt in different places:

#if TARGET_OS_MAC

	#include <Quicktime/QuickTime.h>
	#include <CoreServices/CoreServices.h>
	#include <ApplicationServices/ApplicationServices.h>

#else
	#include <windows.h>
	#include <QTML.h>
	#include <StandardFile.h>
	#include <QuickTimeComponents.h>
	#include "TextUtils.h"
	#include <QuickDraw.h>
	#include "QDOffscreen.h"

#endif

#include "ofConstants.h"


#include "videoGrabber.h"
#include "stdio.h"
#include "string.h"


#define QT_VG_BYTES_PER_PIXEL 			4


class qtVideoGrabber : public videoGrabber{

	public :
	
		qtVideoGrabber(int w, int h);
		virtual void	fillBufferWithVideoData(unsigned char *);
		unsigned char *	returnDataPtr();
		
		virtual void	grabFrame();
		virtual void	close();
		virtual void	initVideo();
		virtual int 	getBytesPerPixel() { return QT_VG_BYTES_PER_PIXEL; };
		void			videoSettings();
		
		int				capSizeW;
		int 			capSizeH;
		
		
		Ptr             baseAddr;
        long            rowBytes;
		
	private:
	
		GWorldPtr 			videogworld;
		SeqGrabComponent	gSeqGrabber;
		SGChannel 			gVideoChannel;
		PixMapHandle 		videoPixMapH;
		unsigned char * 	videoBuffer;
		int 			  	videoRowWidth;
		Rect				videoRect;	
				
}; 






#endif

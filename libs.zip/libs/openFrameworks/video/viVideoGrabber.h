#ifndef _VI_VIDEO_GRABBER
#define _VI_VIDEO_GRABBER

#include "videoGrabber.h"
#include "videoInput.h"

//------------------------------------------------------------------
class viVideoGrabber : public videoGrabber {
	
	public:

		viVideoGrabber (int w, int h);
		virtual void fillBufferWithVideoData(unsigned char * buffer);
		virtual void grabFrame();
		virtual void close();
		virtual void initVideo(){};
		virtual int getBytesPerPixel() { return 3; };		// hmm, can I get this somewhere?
		
		videoInput * VI;
		unsigned char * frame;

}; 
//------------------------------------------------------------------


#endif //_VI_VIDEO_GRABBER




/*


	//ONE CAMERA
	
	videoInput * VI  = new videoInput();
	//VI  ->setPhyCon(VI_S_VIDEO);             //If you need to change the input
	//VI  ->setCaptureSize(0,320,240);		   //if you need a size other than the default
	VI  ->setup(1); //try to setup two cameras.

	unsigned char * frame   = new unsigned char[VI->getSize(0)]; //set the buffer to the size we are capturing at
	while(running)
	{			
		if(VI->grabFrame(0, frame))  //do something with the image
	}
	
	//use VI->getWidth(0) VI->getHeight(0) to get image dimensions,  VI->getSize(0) for image size 

	
	//TWO CAMERAS
	
	videoInput * VI  = new videoInput();
	VI  ->setCaptureSize(0,320,240);		   //Only use if you need a different size than the default
	VI  ->setCaptureSize(1,320,240);	       //Only use if you need a different size than the default
	VI  ->setup(2); //try to setup two cameras.

	unsigned char * frame   = new unsigned char[VI->getSize(0)]; //set the buffer to the size we are capturing at
	unsigned char * frame2  = new unsigned char[VI->getSize(1)]; //set the buffer to the size we are capturing at


	while(running)
	{			
		if(VI->grabFrame(0, frame))  //do something with the image
		if(VI->grabFrame(1, frame2)) //do something with the image
	}

*/
/*


#ifndef _AC_VIDEO_GRABBER
#define _AC_VIDEO_GRABBER


#include "videoGrabber.h"
#include "stdio.h"
#include "string.h"

#define BYTES_PER_PIXEL 				3
#define TOTAL_CAPTURED_IMAGE_SIZE 	(CAPTURE_SIZE_W*CAPTURE_SIZE_H*BYTES_PER_PIXEL)


class acVideoGrabber : public videoGrabber{

	public :
	
		acVideoGrabber();
		virtual void fillBufferWithVideoData(unsigned char *);
		unsigned char *  returnDataPtr();
		
		virtual void grabFrame();
		virtual void close();
		virtual void initVideo();
		void 		videoSettings();
		
		
		qtVideoGrabber * video;
		
	private:
	
}; 

#endif


*/

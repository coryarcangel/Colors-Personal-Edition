#include "qtVideoGrabber.h"




//--------------------------------------------------------------------
//--------------------------------------------------------------------
// static stuff I don't understand exactly, looks like most legacy mac code :(

static pascal Boolean SeqGrabberModalFilterUPP (DialogPtr theDialog, const EventRecord *theEvent, short *itemHit, long refCon){
	
	#pragma unused(theDialog, itemHit)
  	// Ordinarily, if we had multiple windows we cared about, we'd handle
  	// updating them in here, but since we don't, we'll just clear out
  	// any update events meant for us
  
  	Boolean  handled = false;
  
  	if ((theEvent->what == updateEvt) && 
    ((WindowPtr) theEvent->message == (WindowPtr) refCon))
  	{
    	BeginUpdate ((WindowPtr) refCon);
    	EndUpdate ((WindowPtr) refCon);
    	handled = true;
  	}
  	return (handled);

}


//--------------------------------------------------------------------
//--------------------------------------------------------------------




//--------------------------------------------------------------------
qtVideoGrabber::qtVideoGrabber(int w, int h) : videoGrabber(w,h) {
	capSizeW = w;
	capSizeH = h;
	initVideo();
}

//--------------------------------------------------------------------
void qtVideoGrabber::fillBufferWithVideoData(unsigned char * data){


//old 
//	unsigned char * vidPtr = (unsigned char *) baseAddr;
//	for (int i = 0; i < capSizeH; i++){
//		memcpy(data, vidPtr, capSizeW*QT_VG_BYTES_PER_PIXEL);
//		vidPtr += rowBytes;
//		data += capSizeW*QT_VG_BYTES_PER_PIXEL;
//	}
		

// new does ARGB RGBA flipping nice!
	
	#ifdef TARGET_WIN32
		
		//GET PC CAPTURE FROM ZACH
	
	#endif
		
	#ifdef TARGET_OSX

		unsigned char * srcBase;
		unsigned char * trgBase;
		unsigned char *vidPtr =  (unsigned char *)baseAddr;
		
		int rowSize = capSizeW * QT_VG_BYTES_PER_PIXEL;	
		for (int i = 0; i < capSizeH; i++)
		{
			srcBase = vidPtr + i * rowBytes + 1; //+1 makes it RGBA instead of ARGB - Hallalehuh!
			trgBase = data + i * rowSize;
			memcpy(trgBase, srcBase, rowSize);
		}
		
	#endif


//Idea Borrowed From ... http://www1.in.tum.de/twiki/bin/view/Lehrstuhl/OpenCVPlayground
// Transform Pixmap for openCV...
//	PixMapHandle	pix = GetGWorldPixMap([myViewObject gworld]);
//	Rect		bounds;
//	
//	GetPortBounds([myViewObject gworld], &bounds);
//
//	unsigned int y, srcBase, trgBase;
//	unsigned int srcRowSize = (unsigned int)GetPixRowBytes(pix);
//	unsigned int srcPixBase = (unsigned int)GetPixBaseAddr(pix);
//	
//	unsigned int trgRowSize = [myViewObject getSource ] -> widthStep;
//	unsigned int trgPixBase = (unsigned int)([myViewObject getSource ] -> imageData);
//	
//    for (y = 0; y < bounds.bottom; y++)
//    {
//      srcBase = srcPixBase + y * srcRowSize + 1; //+1 due to ARGB vs RGBA!
//      trgBase = trgPixBase + y * trgRowSize;
//		memcpy ((char*)trgBase, (char*)srcBase, trgRowSize);
//    }	
	
	
	
	

	

	
}	

//--------------------------------------------------------------------
void qtVideoGrabber::grabFrame(){

	SGIdle(gSeqGrabber);
}

//--------------------------------------------------------------------
void qtVideoGrabber::close(){

}

//--------------------------------------------------------------------
void qtVideoGrabber::videoSettings(void)
{
	Rect	newActiveVideoRect;
	Rect	adjustedActiveVideoRect;
	Rect	curBounds, curVideoRect, newVideoRect, newBounds;
	short	width, height;
	ComponentResult	err;
	GrafPtr	savedPort;
	RgnHandle	deadRgn;
	SGModalFilterUPP	seqGragModalFilterUPP;
	
	// Get our current state
	err = SGGetChannelBounds (gVideoChannel, &curBounds);
	err = SGGetVideoRect (gVideoChannel, &curVideoRect);
	
	// Pause
	err = SGPause (gSeqGrabber, true);
		
	// Do the dialog thang
	static SGModalFilterUPP gSeqGrabberModalFilterUPP =
	NewSGModalFilterUPP(SeqGrabberModalFilterUPP);
	int result = SGSettingsDialog(gSeqGrabber, gVideoChannel, 0, nil, seqGrabSettingsPreviewOnly, gSeqGrabberModalFilterUPP, nil);
	//printf("%d\n", result);
		
	#if !TARGET_OS_MAC
		// This is necessary, for now, to get the grab to start again afer the
		// dialog goes away.  For some reason the video destRect never gets reset to point
		// back to the monitor window.
		SGSetChannelBounds(gVideoChannel, &videoRect);
	#endif

	// The pause that refreshes
	err = SGPause (gSeqGrabber, false);
}



//--------------------------------------------------------------------
void qtVideoGrabber::initVideo(){
	
	ComponentDescription 	    theDesc;
	ComponentResult 			theresult;
	Component 					sgCompID = NULL;

	char name[256];
 	char info[256];
	Handle componentName=NULL;
 	Handle componentInfo=NULL;
 	
 	ComponentDescription info_description;
 	
	EnterMovies();
	
	
	componentName=NewHandle(sizeof(name));
	componentInfo=NewHandle(sizeof(info));
	
	gSeqGrabber = 0L;
	gVideoChannel = 0L;
	
	
	theDesc.componentType = SeqGrabComponentType;
	theDesc.componentSubType = 0L;
	theDesc.componentManufacturer = 0L; //'appl';
	theDesc.componentFlags = 0L;
	theDesc.componentFlagsMask = 0L;
	
	
	sgCompID = FindNextComponent(sgCompID, &theDesc);
	
	while (sgCompID != 0){
	
			GetComponentInfo(sgCompID,&info_description, componentName, componentInfo,nil);
			printf("found a device to capture with \n");
			printf("Type: %s\n", &info_description.componentType);
			printf("Manufacturer: %s\n", &info_description.componentManufacturer);
			printf("Name: %s\n", *componentName ? p2cstr((StringPtr)*componentName) : "-" );
			printf("Name: %s\n", *componentInfo ? p2cstr((StringPtr)*componentInfo) : "-");
  			
			gSeqGrabber = (VideoDigitizerComponent)OpenComponent(sgCompID);
  			//gSeqGrabber == 0L;
  			sgCompID 	= FindNextComponent(sgCompID, &theDesc);
			
			
	} 
 

  	DigitizerInfo vdigInfo;
			VDGetDigitizerInfo(gSeqGrabber, &vdigInfo);
			if ( vdigInfo.inputCapabilityFlags & digiInDoesComposite){
			 	// finding out about composite...
			}

	MacSetRect(&videoRect,0, 0, capSizeW, capSizeH);
	
	// Get the digitizer rect to test destination params
	SGInitialize(gSeqGrabber);
	QTNewGWorld( &videogworld ,  k32ARGBPixelFormat , &videoRect, nil, nil, 0);                         // IV-2817
	GWorldPtr       offWorld = (GWorldPtr)videogworld;
	baseAddr = GetPixBaseAddr(GetGWorldPixMap(offWorld));
	
	#ifdef TARGET_OSX
		rowBytes = GetPixRowBytes(GetGWorldPixMap(offWorld));
	#endif
      
	videoPixMapH = GetGWorldPixMap(videogworld);
	videoBuffer = (unsigned char *)GetPixBaseAddr(videoPixMapH );	

	SGSetGWorld(gSeqGrabber, videogworld, nil);
	SGNewChannel(gSeqGrabber, VideoMediaType, &gVideoChannel);
	SGSetChannelUsage(gVideoChannel, seqGrabPreview | seqGrabRecord | seqGrabPlayDuringRecord);
	if (SGSetFrameRate(gVideoChannel,30) != noErr) printf( "error setting 30 fps \n");
	else printf ("set to capture at 30 fps \n");
	SGSetChannelBounds(gVideoChannel, &videoRect);
	SGStartPreview(gSeqGrabber);
	
	ComponentInstance vdig;
 	vdig = SGGetVideoDigitizerComponent(gVideoChannel);

 	if(VDSetInput(vdig, 0)!=noErr)printf("VDSetInput error\n");
	if(VDSetInputStandard (vdig, ntscIn)!=noErr)printf("VDSetInputStandard error\n");
	videoSettings();
}
//--------------------------------------------------------------------

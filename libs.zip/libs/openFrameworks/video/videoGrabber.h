


#ifndef _VIDEO_GRABBER
#define _VIDEO_GRABBER


class videoGrabber {
	
	public:

		videoGrabber (int w, int h){};
		virtual void fillBufferWithVideoData(unsigned char *){};
		virtual void grabFrame(){};
		virtual void close(){};
		virtual void initVideo(){};
		virtual int	 getBytesPerPixel(  ){ return -1; };

}; 

#endif

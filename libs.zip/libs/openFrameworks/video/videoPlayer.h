#ifndef _VIDEO_PLAYER
#define _VIDEO_PLAYER



class videoPlayer {
	
	public:

		videoPlayer ();
		virtual void fillBufferWithVideoData(unsigned char *);
		virtual void grabFrame();
		virtual void goToTime(float pct);
		virtual void getNextFrame(float pct);
		virtual void close();
		float 	getSpeed();

		bool bLooping;
		bool bLoopPalindrome;

}; 

#endif

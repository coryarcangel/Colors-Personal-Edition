#ifndef _QT_VIDEO_PLAYER
#define _QT_VIDEO_PLAYER

#include "ofConstants.h"


#ifdef TARGET_WIN32
	#include <QTML.h>				// Quicktime Headers
	#include <StandardFile.h>
	#include <fixmath.h>
	#include <QuickTimeComponents.h>
	#include "TextUtils.h"
	#include "QuickDraw.h"
#endif

#ifdef TARGET_OSX

#include <CoreServices/CoreServices.h>
#include <QuickTime/QuickTime.h>
#include <ApplicationServices/ApplicationServices.h>

#endif


#include "videoPlayer.h"
#include "stdio.h"
#include "string.h"
#include "ofMain.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define BYTES_PER_PIXEL 				4



class qtVideoPlayer : public videoPlayer{
	
	public:
		
		qtVideoPlayer ();
		qtVideoPlayer (char * fileName);

		virtual void fillBufferWithVideoData(unsigned char *);
		virtual void grabFrame();
		virtual void goToTime(float pct);
		virtual void getNextFrame(float pct);
		virtual void close();
		float getMovieDuration();	
		//<CORY>
		float getMovieTimeAPI();
		float getMovieTimeScaleAPI();
		float getMovieDurationAPI();
		//</CORY>
		float getMoviePct();
		void 	setSpeed(float speed);
		float getSpeed();
		bool loadMovie(char * name);
		
		int 		w, h;
		int 		totalImageSize;
		int 		totalNumFrames;
		int 		currentFrame;
		float  	speed;
		
		
		bool createMovieFromPath(char * path, Movie * movie);
		
		
		GWorldPtr 			offWorld;
		GWorldPtr           gw;
		Movie 				theMovie;
		MovieController 	thePlayer;
		Rect 					rectMovie;
		PixMapHandle 		videoPixMapH;
		unsigned char * 	videoBuffer;	
		unsigned char * 	videoBuffer2;
		void 	setMoviePct(float pct);
		
		float 				pctBlur;
		// zach's insane time idea:
		
		long 					lastTime;
		float 				lastTimeStamp;
		
		float 				durationTime;
		float 				durationPct;
		
		
		
		
		}; 
#endif

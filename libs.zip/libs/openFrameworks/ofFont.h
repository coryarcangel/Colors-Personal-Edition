/************************************************************
																				
OpenFrameworks Library												
																			
File: ofFont.h															
Description: 	BASE FONT LIB

															
Last Modified: 2005.09.04											
Creator: Zachary Lieberman											
Last Modified By: Golan Levin 										
																				
Notes: 																	

-- lets move read / file to utils ?
																	
************************************************************/




#ifndef _OF_FONT_H_
#define _OF_FONT_H_

#include "ofConstants.h"

class ofFont{

	public:

		ofFont(){}
		
		bool					bLoadedOk;
		virtual float 		stringWidth(char *s){ return 0.0f; };
		virtual void 		drawString(char *c, float x, float y){};

};


#endif


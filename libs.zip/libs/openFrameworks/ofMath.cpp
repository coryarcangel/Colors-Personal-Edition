/************************************************************/
//																				//
//	OpenFrameworks Library												//
//																				//
//	File: ofMathLibrary.cpp												//
//																				//
//	Last Modified: 2004.11.03											//
//																				//
/************************************************************/


#include "ofMath.h"



//--------------------------------------------------
void ofSeedRandom() {
	
	// seed random with time
	srand(time(NULL));
}


//--------------------------------------------------
float ofSimpleRandomSF (float x, float y) {

	float high = 0;
	float low = 0;
	float randNum = 0;
	
	// if there is no range, return the value
	if (x == y) return x;
	
	high = MAX(x,y);
	low = MIN(x,y);
	
	randNum = low + ((high-low) * rand()/(RAND_MAX + 1.0)); 

	return randNum;
}

//--------------------------------------------------
int ofSimpleRandomSI (float x, float y) {

	float high = 0;
	float low = 0;
	float randNum = 0;
	
	// if there is no range, return the value
	if (x == y) return (int)x;
	
	high = MAX(x,y);
	low = MIN(x,y);
	
	randNum = low + ((high-low) * rand()/(RAND_MAX + 1.0)); 

	return int(randNum);
}

//--------------------------------------------------
float ofRandomF() {
	float randNum = 0;
	randNum = (rand()/(RAND_MAX + 1.0)) * 2.0 - 1.0; 
	return randNum;
}

//--------------------------------------------------
float ofRandomUF() {

	float randNum = 0;
	
	randNum = rand()/(RAND_MAX + 1.0); 

	return randNum;
}
//--------------------------------------------------

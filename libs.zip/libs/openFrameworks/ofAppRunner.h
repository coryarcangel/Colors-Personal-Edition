/************************************************************
																				
OpenFrameworks Library												
																			
File: 			ofAppRunner.h															
Description: 	I am the glue 								
																				
																				
Last Modified: 2004.11.03											
Creator: Zachary Lieberman											
Last Modified By: 										
																				
Notes: 						


// alot to fix here!											

// can we construct the simpleApp extension in this class, thus allowing for
// opengl like calls in the constructor, we get hosed,
// for example, if you make a texture in the constructor of your simpleApp extension
// which is why we have init...


// better keyboard support :
// no handling of system keys (glfwKeyFunc)
// just a-z, A-Z 0-9 and other symbols...
// results passed as ints in ASCII
// SEE 
// http://www.ascii.cl/
// for info 
// name callbacks nicer?

																				
************************************************************/


#ifndef _OF_APP_RUNNER
#define _OF_APP_RUNNER

#include "ofConstants.h"
#include "ofSimpleApp.h"
#include "ofGeom.h"

void run(int w, int h, int screenMode, ofSimpleApp * OFSA);


#endif	

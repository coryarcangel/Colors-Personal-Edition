/************************************************************
																				
OpenFrameworks Library												
																			
File: OF_AUX.h															
Description: 	I am auxiliary libraries, like FMOD and DEVIL									
																				
									
																				
Notes: 																	


																				
************************************************************/



#ifndef OF_AUX
#define OF_AUX


//#include "ofSampleSound.h"
//#include "ofSampleSoundSystem.h"
#include "qtVideoGrabber.h"
#include "qtVideoPlayer.h"
//#include "viVideoGrabber.h"


#endif
